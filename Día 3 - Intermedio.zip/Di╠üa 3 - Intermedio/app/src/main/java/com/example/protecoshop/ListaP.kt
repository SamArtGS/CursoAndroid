package com.example.protecoshop

class ListaP{
    companion object{
        var productos_comprados = arrayListOf<Producto>()
    }
}